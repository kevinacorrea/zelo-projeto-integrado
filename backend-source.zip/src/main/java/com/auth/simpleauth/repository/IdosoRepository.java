package com.auth.simpleauth.repository;

import com.auth.simpleauth.entity.Idoso;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IdosoRepository extends JpaRepository<Idoso, Long> {
    Optional<Idoso> findByEmail(String email);
    Optional<Idoso> findByEmailIgnoreCase(String email);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT i FROM Idoso i WHERE i.id = :id")
    Optional<Idoso> findByIdForUpdate(@Param("id") Long id);
}
