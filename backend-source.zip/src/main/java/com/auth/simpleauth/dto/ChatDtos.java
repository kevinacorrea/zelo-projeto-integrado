package com.auth.simpleauth.dto;

import com.auth.simpleauth.entity.ChatMensagem;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;

public final class ChatDtos {
    private ChatDtos() {}
    public record EnviarMensagem(Long idosoId, Long familiarId, String texto) {}
    public record Mensagem(Long id, Long remetenteId, String remetenteNome, String texto, OffsetDateTime enviadaEm) {
        public static Mensagem de(ChatMensagem m, ZoneId zone) {
            OffsetDateTime enviadaComFuso = m.getEnviadaEm().atZone(zone).toOffsetDateTime();
            return new Mensagem(m.getId(), m.getRemetente().getId(), m.getRemetente().getNome(), m.getTexto(), enviadaComFuso);
        }
    }
    public record Conversa(Long idosoId, String idosoNome, Long familiarId, String familiarNome, LocalDateTime ultimaMensagem) {}
}
