package com.auth.simpleauth.service;

import com.auth.simpleauth.config.TestableClock;
import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Medicamento;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.repository.DoseRepository;
import com.auth.simpleauth.repository.MedicamentoRepository;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import com.auth.simpleauth.enums.StatusVinculo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DoseService {

    private final DoseRepository doseRepository;
    private final MedicamentoRepository medicamentoRepository;
    private final TestableClock clock;
    private final DoseSchedulerEngine doseSchedulerEngine;
    private final WebPushNotificationService webPushNotificationService;
    private final VinculoFamiliarRepository vinculoFamiliarRepository;

    public DoseService(DoseRepository doseRepository,
                       MedicamentoRepository medicamentoRepository,
                       TestableClock clock,
                       DoseSchedulerEngine doseSchedulerEngine,
                       WebPushNotificationService webPushNotificationService,
                       VinculoFamiliarRepository vinculoFamiliarRepository) {
        this.doseRepository = doseRepository;
        this.medicamentoRepository = medicamentoRepository;
        this.clock = clock;
        this.doseSchedulerEngine = doseSchedulerEngine;
        this.webPushNotificationService = webPushNotificationService;
        this.vinculoFamiliarRepository = vinculoFamiliarRepository;
    }

    public List<Dose> listarPorIdoso(Long idosoId) {
        return doseRepository.findByMedicamentoIdosoId(idosoId);
    }

    public Optional<Dose> buscarPorId(Long id) {
        return doseRepository.findById(id);
    }

    @Transactional
    public Dose confirmarDose(Long doseId) {
        Dose dose = doseRepository.findById(doseId)
                .orElseThrow(() -> new RuntimeException("Dose não encontrada com ID: " + doseId));
        if (dose.getStatus() == StatusDose.TOMADO) return dose;

        List<StatusDose> estadosConfirmaveis = List.of(StatusDose.PENDENTE, StatusDose.NOTIFICADO, StatusDose.ATRASADO);
        if (!estadosConfirmaveis.contains(dose.getStatus())) {
            throw new org.springframework.web.server.ResponseStatusException(
                    org.springframework.http.HttpStatus.CONFLICT, "Esta dose não pode mais ser confirmada.");
        }

        LocalDateTime agoraSimulado = LocalDateTime.now(clock);
        if (dose.getHorarioProgramado().isAfter(agoraSimulado)) {
            throw new org.springframework.web.server.ResponseStatusException(
                    org.springframework.http.HttpStatus.CONFLICT, "Ainda não chegou o horário desta dose.");
        }
        int linhasAfetadas = doseRepository.confirmarSeElegivel(
                doseId, StatusDose.TOMADO, agoraSimulado, estadosConfirmaveis);
        if (linhasAfetadas == 0) {
            Dose atual = doseRepository.findById(doseId)
                    .orElseThrow(() -> new RuntimeException("Dose não encontrada com ID: " + doseId));
            if (atual.getStatus() == StatusDose.TOMADO) return atual;
            throw new org.springframework.web.server.ResponseStatusException(
                    org.springframework.http.HttpStatus.CONFLICT, "Esta dose não pode mais ser confirmada.");
        }

        Dose confirmada = doseRepository.findById(doseId)
                .orElseThrow(() -> new RuntimeException("Dose não encontrada após confirmação: " + doseId));
        gerarProximaDose(confirmada.getMedicamento(), confirmada.getHorarioProgramado());
        vinculoFamiliarRepository.findByIdosoIdAndStatusWithFamiliar(
                confirmada.getMedicamento().getIdoso().getId(), StatusVinculo.ACEITO
        ).forEach(vinculo -> webPushNotificationService.notificar(
                vinculo.getFamiliar().getId(),
                "Medicamento confirmado",
                confirmada.getMedicamento().getIdoso().getNome() + " confirmou o medicamento "
                        + confirmada.getMedicamento().getNome() + ".",
                "/iniciofamiliar/iniciofamiliar.html"));
        return confirmada;
    }

    @Transactional
    public Dose marcarComoAtrasadaOuPerdida(Long doseId, StatusDose novoStatus) {
        Dose dose = doseRepository.findById(doseId)
                .orElseThrow(() -> new RuntimeException("Dose não encontrada com ID: " + doseId));

        dose.setStatus(novoStatus);
        dose.setProximaNotificacao(null);
        return doseRepository.save(dose);
    }

    private void gerarProximaDose(Medicamento medicamento, LocalDateTime horarioAtual) {
        if (medicamento == null || Boolean.FALSE.equals(medicamento.getAtivo())) {
            return;
        }

        LocalDateTime agoraSimulado = LocalDateTime.now(clock);
        LocalDateTime proximoHorario = horarioAtual.plusHours(medicamento.getIntervaloHoras());


        while (proximoHorario.isBefore(agoraSimulado)) {
            proximoHorario = proximoHorario.plusHours(medicamento.getIntervaloHoras());
        }

        if (medicamento.getDataFimTratamento() != null && proximoHorario.isAfter(medicamento.getDataFimTratamento())) {
            medicamento.setAtivo(false);
            medicamentoRepository.save(medicamento);
            return;
        }

        if (doseRepository.existsByMedicamentoIdAndHorarioProgramado(medicamento.getId(), proximoHorario)) return;
        Dose proximaDose = new Dose(medicamento, proximoHorario);
        proximaDose = doseRepository.save(proximaDose);

        doseSchedulerEngine.agendarDose(proximaDose);
    }
}
