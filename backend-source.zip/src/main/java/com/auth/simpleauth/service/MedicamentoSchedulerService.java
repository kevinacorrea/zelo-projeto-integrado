package com.auth.simpleauth.service;

import com.auth.simpleauth.config.TestableClock;
import com.auth.simpleauth.entity.Dose;
import com.auth.simpleauth.entity.Familiar;
import com.auth.simpleauth.entity.Medicamento;
import com.auth.simpleauth.enums.StatusDose;
import com.auth.simpleauth.enums.StatusVinculo;
import com.auth.simpleauth.repository.DoseRepository;
import com.auth.simpleauth.repository.MedicamentoRepository;
import com.auth.simpleauth.repository.VinculoFamiliarRepository;
import com.auth.simpleauth.util.MensagemUtil;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MedicamentoSchedulerService {
    private final DoseRepository doseRepository;
    private final MedicamentoRepository medicamentoRepository;
    private final WebPushNotificationService webPushNotificationService;
    private final TestableClock clock;
    private final VinculoFamiliarRepository vinculoFamiliarRepository;

    public MedicamentoSchedulerService(DoseRepository doseRepository,
                                       MedicamentoRepository medicamentoRepository,
                                       WebPushNotificationService webPushNotificationService,
                                       TestableClock clock,
                                       VinculoFamiliarRepository vinculoFamiliarRepository) {
        this.doseRepository = doseRepository;
        this.medicamentoRepository = medicamentoRepository;
        this.webPushNotificationService = webPushNotificationService;
        this.clock = clock;
        this.vinculoFamiliarRepository = vinculoFamiliarRepository;
    }

    @Scheduled(fixedRate = 3000)
    @Transactional
    public void verificarDosesAgendadas() {
        LocalDateTime agora = LocalDateTime.now(clock);
        List<Dose> dosesParaProcessar = doseRepository.findByStatusInAndHorarioProgramadoLessThanEqual(
                List.of(StatusDose.PENDENTE, StatusDose.NOTIFICADO), agora);
        for (Dose dose : dosesParaProcessar) {
            processarDose(dose, agora);
        }
    }

    @Scheduled(fixedRate = 10000)
    @Transactional
    public void verificarTratamentosExpirados() {
        LocalDateTime agora = LocalDateTime.now(clock);
        List<Medicamento> medicamentosExpirados = medicamentoRepository
                .findByDataFimTratamentoLessThanEqual(agora);
        for (Medicamento med : medicamentosExpirados) {
            try {
                notificarFamiliarTerminoTratamento(med);
                doseRepository.deleteAll(doseRepository.findByMedicamentoId(med.getId()));
                medicamentoRepository.delete(med);
                System.out.println("Tratamento temporário vencido removido do banco (medicamento ID " + med.getId() + ").");
            } catch (Exception e) {
                System.err.println("Erro ao excluir medicamento expirado ID " + med.getId() + ": " + e.getMessage());
            }
        }
    }

    private void processarDose(Dose dose, LocalDateTime agora) {
        Medicamento med = dose.getMedicamento();
        StatusDose estadoAtual = dose.getStatus();
        if (Boolean.FALSE.equals(med.getAtivo())) {
            doseRepository.transicionarStatusSeAtual(dose.getId(), estadoAtual, StatusDose.CANCELADO,
                    dose.getQuantidadeNotificacoes(), null);
            return;
        }
        if (med.getDataFimTratamento() != null && !agora.isBefore(med.getDataFimTratamento())) {
            inativarTratamentoExpirado(med, dose, estadoAtual);
            return;
        }

        String nomeMedicamento = med.getNome();
        String nomeIdoso = med.getIdoso().getNome();
        if (estadoAtual == StatusDose.PENDENTE) {
            if (doseRepository.transicionarStatusSeAtual(dose.getId(), StatusDose.PENDENTE, StatusDose.NOTIFICADO,
                    1, agora.plusMinutes(2)) == 0) return;
            dose.setStatus(StatusDose.NOTIFICADO);
            dose.setQuantidadeNotificacoes(1);
            dose.setProximaNotificacao(agora.plusMinutes(2));
            String mensagemAcessivel = MensagemUtil.montarMensagemAcessivel(dose);
            webPushNotificationService.notificar(
                    med.getIdoso().getId(), "Hora do medicamento",
                    mensagemAcessivel.replaceAll("<[^>]*>", ""), "/");
            return;
        }

        if (estadoAtual == StatusDose.NOTIFICADO && dose.getProximaNotificacao() != null
                && !agora.isBefore(dose.getProximaNotificacao())) {
            int tentativas = dose.getQuantidadeNotificacoes() + 1;
            if (tentativas == 2) {
                if (doseRepository.atualizarNotificacaoSeDevida(dose.getId(), StatusDose.NOTIFICADO,
                        StatusDose.NOTIFICADO, tentativas, agora.plusMinutes(1), agora) == 0) return;
                String emojiCor = MensagemUtil.obterEmojiCor(med.getCorCaixa());
                String msgReiteracao = String.format(
                        "⚠️ %s, você ainda não confirmou o remédio da caixa %s <b>%s</b> ('<b>%s</b>')!\n"
                                + "Abra o Zelo para confirmar a dose.",
                        nomeIdoso,
                        emojiCor,
                        med.getCorCaixa() != null ? med.getCorCaixa().toUpperCase() : "",
                        nomeMedicamento);
                webPushNotificationService.notificar(
                        med.getIdoso().getId(), "Lembrete de medicamento",
                        msgReiteracao.replaceAll("<[^>]*>", ""), "/");
            } else {
                if (doseRepository.atualizarNotificacaoSeDevida(dose.getId(), StatusDose.NOTIFICADO,
                        StatusDose.ATRASADO, tentativas, null, agora) == 0) return;
                dose.setStatus(StatusDose.ATRASADO);
                dose.setQuantidadeNotificacoes(tentativas);
                dose.setProximaNotificacao(null);
                notificarFamiliarAtraso(dose);
            }
        }
    }

    private void inativarTratamentoExpirado(Medicamento med, Dose dose, StatusDose estadoAtual) {
        med.setAtivo(false);
        medicamentoRepository.save(med);
        doseRepository.transicionarStatusSeAtual(dose.getId(), estadoAtual, StatusDose.CANCELADO,
                dose.getQuantidadeNotificacoes(), null);
    }

    private void notificarFamiliarTerminoTratamento(Medicamento med) {
        vinculoFamiliarRepository.findByIdosoIdAndStatusWithFamiliar(
                med.getIdoso().getId(), StatusVinculo.ACEITO
        ).forEach(vinculo -> {
            Familiar familiar = vinculo.getFamiliar();
            webPushNotificationService.notificar(
                    familiar.getId(), "Tratamento concluído",
                    "O tratamento de " + med.getNome() + " para " + med.getIdoso().getNome() + " terminou.", "/");
        });
    }

    private void notificarFamiliarAtraso(Dose dose) {
        vinculoFamiliarRepository.findByIdosoIdAndStatusWithFamiliar(
                dose.getMedicamento().getIdoso().getId(), StatusVinculo.ACEITO
        ).forEach(vinculo -> {
            Familiar familiar = vinculo.getFamiliar();
            webPushNotificationService.notificar(
                    familiar.getId(), "Dose não confirmada",
                    dose.getMedicamento().getIdoso().getNome() + " não confirmou "
                            + dose.getMedicamento().getNome() + " no horário previsto.", "/");
        });
    }
}
