(() => {
    'use strict';

    const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';

    function formatarHorario(valor) {
        if (!valor) return '';
        const data = Array.isArray(valor)
            ? new Date(valor[0], (valor[1] || 1) - 1, valor[2] || 1, valor[3] || 0, valor[4] || 0, valor[5] || 0)
            : new Date(valor);
        return Number.isNaN(data.getTime())
            ? String(valor)
            : data.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    }

    document.addEventListener('DOMContentLoaded', () => {
        const botao = document.getElementById('btn-sininho');
        const painel = document.getElementById('notif-dropdown');
        const lista = document.getElementById('notif-lista');
        const badge = document.getElementById('notif-badge');
        const limpar = document.getElementById('btn-limpar-notif');

        if (!botao || !painel || !lista || !badge) return;

        let notificacoes = [];
        let carregando = false;

        const atualizarAria = () => {
            botao.setAttribute('aria-expanded', String(painel.classList.contains('is-open')));
        };

        const renderizar = (erro = '') => {
            lista.replaceChildren();

            if (erro) {
                const mensagem = document.createElement('p');
                mensagem.className = 'notif-empty';
                mensagem.textContent = erro;
                lista.appendChild(mensagem);
                badge.hidden = true;
                return;
            }

            if (!notificacoes.length) {
                const vazio = document.createElement('p');
                vazio.className = 'notif-empty';
                vazio.textContent = carregando ? 'Carregando notificações...' : 'Nenhuma notificação no momento.';
                lista.appendChild(vazio);
                badge.hidden = true;
                return;
            }

            badge.textContent = String(notificacoes.length);
            badge.hidden = false;

            notificacoes.forEach((notificacao) => {
                const item = document.createElement('div');
                item.className = 'notif-item';

                const texto = document.createElement('div');
                texto.className = 'notif-item-text';
                texto.textContent = `${notificacao.titulo ? `${notificacao.titulo}: ` : ''}${notificacao.mensagem || 'Nova notificação.'}`;

                const horario = document.createElement('div');
                horario.className = 'notif-item-time';
                horario.textContent = formatarHorario(notificacao.criadaEm || notificacao.hora);

                item.append(texto, horario);
                lista.appendChild(item);
            });
        };

        const carregar = async () => {
            if (carregando) return;
            carregando = true;
            renderizar();

            try {
                const resposta = await fetch(`${API_BASE_URL}/notificacoes`, {
                    credentials: 'include',
                    cache: 'no-store'
                });
                if (!resposta.ok) {
                    throw new Error(resposta.status === 401
                        ? 'Sua sessão expirou. Entre novamente.'
                        : `Não foi possível carregar as notificações (HTTP ${resposta.status}).`);
                }
                notificacoes = await resposta.json();
                localStorage.removeItem('zelo_notificacoes_salvas');
                renderizar();
            } catch (erro) {
                renderizar(erro.message || 'Falha ao carregar as notificações.');
            } finally {
                carregando = false;
            }
        };

        const fechar = () => {
            painel.classList.remove('is-open');
            atualizarAria();
        };

        botao.addEventListener('click', async (event) => {
            event.stopPropagation();
            painel.classList.toggle('is-open');
            atualizarAria();
            if (painel.classList.contains('is-open')) await carregar();
        });

        painel.addEventListener('click', (event) => event.stopPropagation());
        document.addEventListener('click', fechar);
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') fechar();
        });

        limpar?.addEventListener('click', async (event) => {
            event.stopPropagation();
            limpar.disabled = true;
            try {
                const resposta = await fetch(`${API_BASE_URL}/notificacoes`, {
                    method: 'DELETE',
                    credentials: 'include'
                });
                if (!resposta.ok) throw new Error(await resposta.text() || `Erro ${resposta.status} ao limpar notificações.`);
                notificacoes = [];
                renderizar();
            } catch (erro) {
                renderizar(erro.message || 'Não foi possível limpar as notificações.');
            } finally {
                limpar.disabled = false;
            }
        });

        window.addEventListener('zelo-web-push', () => window.setTimeout(carregar, 250));
        window.addEventListener('focus', carregar);
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') carregar();
        });

        atualizarAria();
        renderizar();
        carregar();
        window.setInterval(carregar, 10000);
    });
})();
