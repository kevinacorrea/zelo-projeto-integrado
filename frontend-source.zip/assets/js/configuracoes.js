(() => {
  'use strict';
  const API = window.ZELO_API_BASE_URL || 'http://localhost:8080';
  const $ = (selector) => document.querySelector(selector);
  const REQUEST_TIMEOUT_MS = 60000;
  let usuario = null;
  let perfil = null;
  let carregandoPerfil = false;

  function status(mensagem, erro = false, mostrarRetry = false) {
    const el = $('#page-status');
    if (!el) return;
    el.textContent = mensagem;
    el.classList.toggle('error', erro);
    const retry = $('#retry-profile');
    if (retry) retry.hidden = !mostrarRetry;
  }
  async function request(url, options = {}) {
    const { timeoutMs = REQUEST_TIMEOUT_MS, ...fetchOptions } = options;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(`${API}${url}`, {
        credentials: 'include', cache: 'no-store', ...fetchOptions, signal: controller.signal,
        headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) }
      });
      const text = await response.text();
      let data = text;
      try { data = text ? JSON.parse(text) : {}; } catch (_) {}
      if (!response.ok) {
        const message = typeof data === 'string' ? data : (data.message || data.errors?.join(' ') || `Não foi possível concluir (${response.status}).`);
        const error = new Error(message);
        error.status = response.status;
        throw error;
      }
      return data;
    } catch (error) {
      if (error.name === 'AbortError') {
        const timeoutError = new Error('O servidor do Zelo demorou para responder.');
        timeoutError.code = 'TIMEOUT';
        throw timeoutError;
      }
      if (error instanceof TypeError) {
        throw new Error('Não foi possível conectar ao servidor do Zelo. Confira sua conexão.');
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }
  function salvarUsuarioLocal() {
    const merged = { ...(usuario || {}), ...(perfil || {}) };
    merged.userType = String(merged.perfil || merged.tipo || usuario?.userType || '').toLowerCase();
    localStorage.setItem('currentUser', JSON.stringify(merged));
    usuario = merged;
  }
  function destinoPainel() {
    return usuario?.userType === 'familiar' ? 'iniciofamiliar/iniciofamiliar.html' : 'inicioidoso/inicioidoso.html';
  }
  function definirFoto(dataUrl) {
    const image = $('#profile-photo');
    const initials = $('#profile-initials');
    const remove = $('#remove-photo');
    const fotoSegura = typeof dataUrl === 'string' && dataUrl.length <= 500000 &&
      (dataUrl.startsWith('data:image/jpeg;base64,') || dataUrl.startsWith('https://'));
    if (fotoSegura) {
      image.src = dataUrl;
      image.hidden = false;
      initials.hidden = true;
      remove.hidden = false;
    } else {
      image.removeAttribute('src');
      image.hidden = true;
      initials.hidden = false;
      remove.hidden = true;
      const nome = perfil?.nome || usuario?.nome || 'Zelo';
      initials.textContent = nome.trim().split(/\s+/).slice(0, 2).map(p => p[0]?.toUpperCase()).join('') || 'Z';
    }
  }
  function habilitarAcoesDePerfil(habilitar) {
    document.querySelectorAll('#profile-form input, #profile-form button, #password-form input, #password-form button, #delete-form input, #delete-form button, #photo-file, #remove-photo, #logout-all')
      .forEach((control) => { control.disabled = !habilitar; });
    const photoLabel = document.querySelector('label[for="photo-file"]');
    if (photoLabel) {
      photoLabel.classList.toggle('is-disabled', !habilitar);
      photoLabel.setAttribute('aria-disabled', String(!habilitar));
    }
  }
  function restaurarPerfilLocal() {
    try {
      const salvo = JSON.parse(localStorage.getItem('currentUser') || 'null');
      if (!salvo || typeof salvo !== 'object') return;
      const tipo = String(salvo.userType || salvo.perfil || salvo.tipo || '').toLowerCase();
      if (!['idoso', 'familiar'].includes(tipo)) return;
      usuario = { ...salvo, userType: tipo };
      perfil = { ...salvo };
      $('#profile-name').textContent = salvo.nome || 'Perfil salvo neste aparelho';
      $('#profile-email-summary').textContent = salvo.email || '';
      $('#profile-kind').textContent = tipo === 'idoso' ? 'Perfil idoso' : 'Perfil familiar';
      $('#name').value = salvo.nome || '';
      $('#email').value = salvo.email || '';
      $('#phone').value = salvo.telefone || '';
      $('#voltar-painel').href = destinoPainel();
      $('#footer-back').href = destinoPainel();
      $('#audio-home-link').href = destinoPainel();
      definirFoto(salvo.imagemUrl || '');
      status('Exibindo os últimos dados salvos neste aparelho enquanto verificamos a conexão.');
    } catch (_) {
      // Dados locais inválidos não impedem a validação da sessão no servidor.
    }
  }
  async function carregarPerfil() {
    if (carregandoPerfil) return false;
    carregandoPerfil = true;
    const retry = $('#retry-profile');
    if (retry) {
      retry.disabled = true;
      retry.textContent = 'Conectando…';
    }
    status('Conectando ao servidor do Zelo…');
    const avisoLento = setTimeout(() => {
      if (carregandoPerfil) status('O servidor pode estar iniciando. Aguarde ou tente novamente se a conexão falhar.');
    }, 8000);
    try {
      let perfilRecebido;
      const tipoSalvo = String(usuario?.userType || usuario?.perfil || usuario?.tipo || '').toLowerCase();
      if (usuario?.id && ['idoso', 'familiar'].includes(tipoSalvo)) {
        try {
          perfilRecebido = await request(`/usuarios/${encodeURIComponent(usuario.id)}`);
        } catch (error) {
          if (![401, 403, 404].includes(error.status)) throw error;
          usuario = await request('/login');
          usuario.userType = String(usuario.perfil || usuario.tipo || '').toLowerCase();
          if (!['idoso', 'familiar'].includes(usuario.userType)) {
            localStorage.removeItem('currentUser');
            window.location.replace('login.html');
            return false;
          }
          perfilRecebido = await request(`/usuarios/${encodeURIComponent(usuario.id)}`);
        }
      } else {
        usuario = await request('/login');
        usuario.userType = String(usuario.perfil || usuario.tipo || '').toLowerCase();
        if (!['idoso', 'familiar'].includes(usuario.userType)) {
          localStorage.removeItem('currentUser');
          window.location.replace('login.html');
          return false;
        }
        perfilRecebido = await request(`/usuarios/${encodeURIComponent(usuario.id)}`);
      }
      perfil = perfilRecebido;
      usuario.userType = String(perfil.perfil || perfil.tipo || usuario.userType || '').toLowerCase();
      if (!['idoso', 'familiar'].includes(usuario.userType)) {
        localStorage.removeItem('currentUser');
        window.location.replace('login.html');
        return false;
      }
      $('#profile-name').textContent = perfil.nome || 'Minha conta';
      $('#profile-email-summary').textContent = perfil.email || '';
      $('#profile-kind').textContent = usuario.userType === 'idoso' ? 'Perfil idoso' : 'Perfil familiar';
      $('#name').value = perfil.nome || '';
      $('#email').value = perfil.email || '';
      $('#phone').value = perfil.telefone || '';
      $('#voltar-painel').href = destinoPainel();
      $('#footer-back').href = destinoPainel();
      $('#audio-home-link').href = destinoPainel();
      definirFoto(perfil.imagemUrl || '');
      salvarUsuarioLocal();
      habilitarAcoesDePerfil(true);
      status('');
      return true;
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        localStorage.removeItem('currentUser');
        window.location.replace('login.html');
        return false;
      }
      habilitarAcoesDePerfil(false);
      $('#profile-name').textContent = perfil?.nome || usuario?.nome || 'Perfil temporariamente indisponível';
      $('#profile-email-summary').textContent = perfil?.email || usuario?.email || '';
      const mensagem = error.code === 'TIMEOUT'
        ? 'O servidor do Zelo está demorando para responder. Confira a conexão e tente novamente.'
        : `Não foi possível carregar o perfil. ${error.message || 'Confira a conexão e tente novamente.'}`;
      status(mensagem, true, true);
      return false;
    } finally {
      clearTimeout(avisoLento);
      carregandoPerfil = false;
      if (retry) {
        retry.disabled = false;
        retry.textContent = 'Tentar novamente';
      }
    }
  }
  function aplicarImagemRedimensionada(file) {
    return new Promise((resolve, reject) => {
      if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) return reject(new Error('Escolha uma foto JPEG, PNG ou WebP.'));
      if (file.size > 8 * 1024 * 1024) return reject(new Error('A foto original precisa ter menos de 8 MB.'));
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Não foi possível ler esta imagem.'));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error('O arquivo selecionado não parece ser uma imagem válida.'));
        image.onload = () => {
          const limite = 512;
          const escala = Math.min(1, limite / Math.max(image.naturalWidth, image.naturalHeight));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(image.naturalWidth * escala));
          canvas.height = Math.max(1, Math.round(image.naturalHeight * escala));
          const context = canvas.getContext('2d', { alpha: false });
          context.fillStyle = '#ffffff';
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
          if (dataUrl.length > 410000) return reject(new Error('A foto ficou grande demais. Escolha outra imagem com menos detalhes.'));
          resolve(dataUrl);
        };
        image.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
  }
  async function atualizarCampo(campo, valor) {
    const atualizado = await request(`/usuarios/${usuario.id}/${campo}`, {
      method: 'PUT', body: JSON.stringify({ [campo === 'nome' ? 'nome' : campo]: valor })
    });
    perfil = { ...perfil, ...atualizado };
    salvarUsuarioLocal();
  }
  function configurarFormularios() {
    $('#profile-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      if (!form.reportValidity()) return;
      const email = $('#email').value.trim().toLowerCase();
      const phone = $('#phone').value.trim();
      const name = $('#name').value.trim();
      const digits = phone.replace(/\D/g, '').replace(/^55(?=\d{10,11})/, '');
      if (![10, 11].includes(digits.length)) return status('Informe um telefone válido com DDD.', true);
      const button = form.querySelector('[type=submit]');
      button.disabled = true;
      try {
        if (name !== perfil.nome) await atualizarCampo('nome', name);
        if (email !== perfil.email) await atualizarCampo('email', email);
        if (phone !== perfil.telefone) await atualizarCampo('telefone', phone);
        $('#profile-name').textContent = perfil.nome;
        $('#profile-email-summary').textContent = perfil.email;
        definirFoto(perfil.imagemUrl || '');
        status('Seus dados foram atualizados.');
      } catch (error) {
        const mensagem = String(error.message || '');
        status(/409|telefone.*(cadastrad|exist)|already.*(phone|mobile)/i.test(mensagem)
          ? 'Este telefone já está cadastrado. Use outro número.'
          : mensagem, true);
      }
      finally { button.disabled = false; }
    });

    $('#password-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      if (!form.reportValidity()) return;
      if ($('#new-password').value !== $('#confirm-password').value) return status('A confirmação da nova senha não confere.', true);
      if ($('#current-password').value === $('#new-password').value) return status('Escolha uma senha diferente da atual.', true);
      const button = form.querySelector('[type=submit]');
      button.disabled = true;
      try {
        const result = await request(`/usuarios/${usuario.id}/senha`, {
          method: 'PUT', body: JSON.stringify({ senhaAtual: $('#current-password').value, novaSenha: $('#new-password').value })
        });
        form.reset();
        status(result.message || 'Senha atualizada. Este aparelho continuará conectado.');
      } catch (error) { status(error.message, true); }
      finally { button.disabled = false; }
    });

    $('#photo-file').addEventListener('change', async (event) => {
      const file = event.currentTarget.files?.[0];
      if (!file) return;
      status('Preparando sua foto…');
      try {
        const imagemUrl = await aplicarImagemRedimensionada(file);
        const atualizado = await request(`/usuarios/${usuario.id}/foto`, {
          method: 'PUT', body: JSON.stringify({ imagemUrl })
        });
        perfil = { ...perfil, ...atualizado };
        definirFoto(perfil.imagemUrl);
        salvarUsuarioLocal();
        status('Foto de perfil atualizada.');
      } catch (error) { status(error.message, true); }
      finally { event.currentTarget.value = ''; }
    });

    $('#remove-photo').addEventListener('click', async () => {
      if (!confirm('Remover a foto de perfil?')) return;
      try {
        const atualizado = await request(`/usuarios/${usuario.id}/foto`, { method: 'PUT', body: JSON.stringify({ imagemUrl: null }) });
        perfil = { ...perfil, ...atualizado };
        definirFoto('');
        salvarUsuarioLocal();
        status('Foto removida.');
      } catch (error) { status(error.message, true); }
    });

    document.querySelectorAll('[data-font-choice]').forEach((button) => button.addEventListener('click', () => {
      window.zeloAcessibilidade?.salvar({ fonte: button.dataset.fontChoice });
    }));
    $('#contrast-toggle').addEventListener('change', (event) => window.zeloAcessibilidade?.salvar({ contraste: event.currentTarget.checked }));

    atualizarEstadoNotificacoes();
    $('#enable-notifications').addEventListener('click', async (event) => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        if (typeof window.zeloAtivarNotificacoes !== 'function') throw new Error('Não foi possível carregar o serviço de notificações. Atualize a página e tente novamente.');
        await window.zeloAtivarNotificacoes();
        localStorage.setItem('zeloPushAtivo', 'true');
        status('Notificações ativadas neste navegador.');
      } catch (error) { status(error.message, true); }
      finally { button.disabled = false; atualizarEstadoNotificacoes(); }
    });
    $('#disable-notifications').addEventListener('click', async (event) => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        if (!('serviceWorker' in navigator)) throw new Error('Este navegador não oferece notificações push.');
        const scope = new URL('/', window.location.origin).pathname;
        const registration = await navigator.serviceWorker.getRegistration(scope);
        const subscription = await registration?.pushManager.getSubscription();
        if (subscription) {
          await request('/notificacoes/push/inscricoes', {
            method: 'DELETE', body: JSON.stringify({ endpoint: subscription.endpoint })
          });
          await subscription.unsubscribe();
        }
        localStorage.removeItem('zeloPushAtivo');
        localStorage.removeItem('zeloPushUsuarioId');
        localStorage.removeItem('zeloPushVerificadoEm');
        status('Notificações desativadas neste navegador.');
      } catch (error) { status(error.message, true); }
      finally { button.disabled = false; atualizarEstadoNotificacoes(); }
    });

    $('#logout-all').addEventListener('click', async (event) => {
      if (!confirm('Sair de todos os aparelhos? Os acessos lembrados serão revogados e você voltará à tela de entrada.')) return;
      event.currentTarget.disabled = true;
      try {
        await request(`/usuarios/${usuario.id}/acessos-lembrados`, { method: 'DELETE' });
        localStorage.removeItem('currentUser');
        localStorage.removeItem('selectedIdoso');
        window.location.replace('login.html');
      } catch (error) { status(error.message, true); event.currentTarget.disabled = false; }
    });
    $('#logout-current').addEventListener('click', () => window.sairDaConta());

    $('#delete-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!event.currentTarget.reportValidity()) return;
      if (!confirm('Esta ação é permanente. Tem certeza de que deseja excluir sua conta?')) return;
      const button = event.currentTarget.querySelector('[type=submit]');
      button.disabled = true;
      try {
        await request(`/usuarios/${usuario.id}`, { method: 'DELETE', body: JSON.stringify({ senha: $('#delete-password').value }) });
        localStorage.removeItem('currentUser');
        localStorage.removeItem('selectedIdoso');
        alert('Sua conta foi excluída.');
        window.location.replace('paginainicial/paginainicial.html');
      } catch (error) { status(error.message, true); button.disabled = false; }
    });
  }
  function atualizarEstadoNotificacoes() {
    const state = $('#notification-state');
    const button = $('#enable-notifications');
    const disableButton = $('#disable-notifications');
    let usuarioPush = String(usuario?.id || '');
    if (!usuarioPush) {
      try { usuarioPush = String(JSON.parse(localStorage.getItem('currentUser') || 'null')?.id || ''); } catch (_) {}
    }
    const pushAtivoParaUsuario = localStorage.getItem('zeloPushAtivo') === 'true' &&
      localStorage.getItem('zeloPushUsuarioId') === usuarioPush;
    if (disableButton) disableButton.hidden = !pushAtivoParaUsuario;
    if (!('Notification' in window)) {
      state.textContent = 'Este navegador não oferece notificações push.';
      button.disabled = true;
      return;
    }
    const permission = Notification.permission;
    if (permission === 'granted' && pushAtivoParaUsuario) {
      state.textContent = 'Notificações estão ativadas neste aparelho.';
      button.textContent = 'Atualizar inscrição de notificações';
    } else if (permission === 'denied') {
      state.textContent = 'As notificações estão bloqueadas. Libere a permissão nas configurações do navegador para ativá-las.';
      button.textContent = 'Permissão bloqueada no navegador';
      button.disabled = true;
    } else {
      state.textContent = 'As notificações estão desativadas neste aparelho.';
    }
  }
  window.sairDaConta = async () => {
    try { await request('/login/logout', { method: 'POST' }); } catch (_) {}
    localStorage.removeItem('currentUser');
    localStorage.removeItem('selectedIdoso');
    window.location.replace('login.html');
  };
  document.addEventListener('DOMContentLoaded', () => {
    configurarFormularios();
    habilitarAcoesDePerfil(false);
    restaurarPerfilLocal();
    $('#retry-profile').addEventListener('click', carregarPerfil);
    carregarPerfil();
  });
})();
