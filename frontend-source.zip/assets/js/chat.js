(() => {
  const API = window.ZELO_API_BASE_URL || 'http://localhost:8080';
  let contatos = [], conversaIdoso = null, conversaFamiliar = null, ultimaMensagem = 0, conversaInicializada = false, timer, timerNotificacoes, reconhecimento, carregamentoMensagens = 0, carregandoNotificacoes = false;
  const user = () => { try { return JSON.parse(localStorage.getItem('currentUser') || '{}'); } catch (_) { return {}; } };
  const selected = () => { try { return JSON.parse(localStorage.getItem('selectedIdoso') || 'null'); } catch (_) { return null; } };
  const el = id => document.getElementById(id);
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const urlNotificacao = value => { try { const url = new URL(value || '/', location.origin); return url.origin === location.origin ? `${url.pathname}${url.search}${url.hash}` : '/'; } catch (_) { return '/'; } };
  const telefone = value => String(value || '').replace(/\D/g, '');
  function formatarHorarioMensagem(valor) {
    if (!valor) return '';
    const texto = String(valor);
    const possuiFuso = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(texto);
    if (possuiFuso) {
      const data = new Date(texto);
      if (!Number.isNaN(data.getTime())) return data.toLocaleTimeString('pt-BR', {timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'});
    }
    const horarioLocal = texto.match(/T(\d{2}):(\d{2})/);
    if (horarioLocal) return `${horarioLocal[1]}:${horarioLocal[2]}`;
    const data = new Date(texto);
    return Number.isNaN(data.getTime()) ? '' : data.toLocaleTimeString('pt-BR', {timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'});
  }
  async function carregarContatos() {
    const u = user(); if (!u.id) return;
    try {
      const familiar = String(u.userType || u.perfil || '').toLowerCase() === 'familiar';
      const r = await fetch(`${API}/api/vinculos/${familiar ? `familiar/${u.id}/idosos` : `idoso/${u.id}/familiares`}`, {credentials:'include', cache:'no-store'});
      contatos = r.ok ? await r.json() : [];
      const contatoEmergencia = document.querySelector('.emergency-btn.family');
      const telefoneEmergencia = telefone(contatos[0]?.telefone);
      if (contatoEmergencia && telefoneEmergencia) contatoEmergencia.href = `tel:${telefoneEmergencia}`;
      const select = el('chat-contact-select'); if (!select) return;
      const valorAtual = select.value;
      select.innerHTML = contatos.length ? contatos.map(c => `<option value="${c.id}">${escapeHtml(c.nome || `Perfil ${c.id}`)}</option>`).join('') : '<option value="">Nenhum vínculo aprovado</option>';
      const s = selected();
      const alvo = familiar
        ? (contatos.some(c => String(c.id) === String(valorAtual)) ? String(valorAtual) : (contatos.some(c => String(c.id) === String(s?.id)) ? String(s.id) : String(contatos[0]?.id || '')))
        : (contatos.some(c => String(c.id) === String(valorAtual)) ? String(valorAtual) : String(contatos[0]?.id || ''));
      if (alvo) {
        if (familiar) {
          conversaIdoso = alvo;
          conversaFamiliar = String(u.id);
          select.value = alvo;
        } else {
          conversaIdoso = String(u.id);
          conversaFamiliar = alvo;
          select.value = alvo;
        }
        await carregarMensagens();
      }
    } catch (e) { console.warn('Não foi possível carregar os vínculos:', e); }
  }
  async function carregarMensagens() {
    if (!conversaIdoso) return;
    const token = ++carregamentoMensagens;
    const idosoId = String(conversaIdoso);
    const familiarId = conversaFamiliar ? String(conversaFamiliar) : '';
    const query = new URLSearchParams({idosoId});
    if (familiarId) query.set('familiarId', familiarId);
    try {
      const r = await fetch(`${API}/api/chat/mensagens?${query.toString()}`, {credentials:'include', cache:'no-store'});
      if (!r.ok || token !== carregamentoMensagens) return;
      const lista = await r.json(); const box = el('chat-messages'); if (!box) return;
    box.innerHTML = lista.length ? lista.map(m => `<div class="chat-message ${m.remetenteId === user().id ? 'mine' : ''}"><strong>${escapeHtml(m.remetenteNome)}</strong><span>${escapeHtml(m.texto)}</span><div class="chat-message-actions"><button type="button" class="chat-speak" data-text="${escapeHtml(m.texto)}" aria-label="Ouvir esta mensagem">🔊 Ouvir</button><time>${formatarHorarioMensagem(m.enviadaEm)}</time></div></div>`).join('') : '<p class="chat-empty">Ainda não há mensagens. Envie um oi!</p>';
    box.querySelectorAll('.chat-speak').forEach(button => button.addEventListener('click', () => window.lerMensagemChat(button.dataset.text)));
    const ultimo = lista[lista.length - 1];
    if (ultimo && ultimo.id !== ultimaMensagem) {
      const eraNova = conversaInicializada && ultimo.remetenteId !== user().id;
      ultimaMensagem = ultimo.id; box.scrollTop = box.scrollHeight;
      if (eraNova && el('chat-auto-audio')?.checked) window.lerMensagemChat(`${ultimo.remetenteNome} disse: ${ultimo.texto}`);
    }
      conversaInicializada = true;
    } catch (erro) {
      if (token === carregamentoMensagens) console.warn('Não foi possível carregar as mensagens:', erro);
    }
  }
  async function enviar(e) {
    e.preventDefault();
    const input = el('chat-input'); const texto = input?.value.trim();
    if (!texto || !conversaIdoso) return;
    const payload = {idosoId:Number(conversaIdoso), texto};
    if (conversaFamiliar) payload.familiarId = Number(conversaFamiliar);
    try {
      const r = await fetch(`${API}/api/chat/mensagens`, {method:'POST', credentials:'include', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
      if (!r.ok) throw new Error(await r.text() || 'Não foi possível enviar a mensagem.');
      input.value = '';
      await carregarMensagens();
    } catch (erro) { alert(erro.message || 'Não foi possível enviar a mensagem.'); }
  }
  window.lerMensagemChat = texto => { if (!('speechSynthesis' in window) || !texto) return; window.speechSynthesis.cancel(); const fala = new SpeechSynthesisUtterance(texto); fala.lang = 'pt-BR'; fala.rate = 0.88; fala.pitch = 1; window.speechSynthesis.speak(fala); };
  function iniciarDitado() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { alert('O ditado por voz não está disponível neste navegador.'); return; }
    if (reconhecimento) { reconhecimento.stop(); reconhecimento = null; return; }
    reconhecimento = new SpeechRecognition(); reconhecimento.lang = 'pt-BR'; reconhecimento.interimResults = false; reconhecimento.maxAlternatives = 1;
    reconhecimento.onstart = () => { const b = el('chat-mic'); if (b) b.textContent = '⏹️ Parar'; };
    reconhecimento.onresult = event => { const input = el('chat-input'); if (input) input.value = `${input.value ? `${input.value} ` : ''}${event.results[0][0].transcript}`; };
    reconhecimento.onerror = () => { const b = el('chat-mic'); if (b) b.textContent = '🎙️ Falar'; };
    reconhecimento.onend = () => { const b = el('chat-mic'); if (b) b.textContent = '🎙️ Falar'; reconhecimento = null; };
    reconhecimento.start();
  }
  async function carregarNotificacoes() {
    const badge = el('notif-badge'); const list = el('notif-list');
    if (!badge || !list || carregandoNotificacoes) return;
    carregandoNotificacoes = true;
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 15000);
    try {
      let r = await fetch(`${API}/notificacoes`, {credentials:'include', cache:'no-store', signal:controller.signal});
      if (r.status === 401) {
        const sessao = await fetch(`${API}/login`, {credentials:'include', cache:'no-store', signal:controller.signal});
        if (sessao.ok) r = await fetch(`${API}/notificacoes`, {credentials:'include', cache:'no-store', signal:controller.signal});
      }
      if (!r.ok) {
        if (r.status === 401 || r.status === 403) throw new Error('Sua sessão expirou. Entre novamente para ver as notificações.');
        let detalhe = '';
        try { const erro = await r.json(); detalhe = erro.message || erro.error || ''; } catch (_) {}
        throw new Error(detalhe || `Não foi possível carregar as notificações (HTTP ${r.status}).`);
      }
      const recebido = await r.json();
      if (!Array.isArray(recebido)) throw new Error('O servidor retornou uma resposta de notificações inválida.');
      const n = recebido;
      badge.textContent = n.length;
      badge.classList.toggle('hidden', !n.length);
      list.innerHTML = n.length ? n.map(x => `<li class="notif-item new"><a class="notif-link" href="${escapeHtml(urlNotificacao(x.url))}"><span class="notif-item-icon" aria-hidden="true">🔔</span><span class="notif-item-content"><strong>${escapeHtml(x.titulo || 'Notificação')}</strong><span>${escapeHtml(x.mensagem || '')}</span><small>${new Date(x.criadaEm).toLocaleString('pt-BR')}</small></span></a></li>`).join('') : '<li class="notif-item empty"><span aria-hidden="true">✅</span><span>Nenhuma notificação no momento.</span></li>';
    } catch (erro) {
      const mensagem = erro.name === 'AbortError' ? 'O servidor demorou para responder. Verifique a conexão e tente novamente.' : (erro.message || 'Falha ao carregar as notificações.');
      badge.classList.add('hidden');
      list.replaceChildren();
      const aviso = document.createElement('li'); aviso.className = 'notif-item empty'; aviso.setAttribute('role', 'status'); aviso.textContent = mensagem;
      const acoes = document.createElement('li'); acoes.className = 'notif-error-actions';
      const tentar = document.createElement('button'); tentar.type = 'button'; tentar.className = 'notif-retry-btn'; tentar.textContent = 'Tentar novamente';
      tentar.addEventListener('click', () => carregarNotificacoes());
      acoes.appendChild(tentar); list.append(aviso, acoes);
    } finally {
      window.clearTimeout(timeout);
      carregandoNotificacoes = false;
    }
  }
  window.toggleNotificacoes = () => { const drawer = el('notif-drawer'); const bell = el('bell-btn'); if (!drawer) return; const aberto = drawer.classList.toggle('hidden') === false; drawer.setAttribute('aria-expanded', String(aberto)); bell?.setAttribute('aria-expanded', String(aberto)); if (aberto) carregarNotificacoes(); };
  document.addEventListener('click', evento => { const drawer = el('notif-drawer'); const bell = el('bell-btn'); if (drawer && !drawer.classList.contains('hidden') && !drawer.contains(evento.target) && !bell?.contains(evento.target)) { drawer.classList.add('hidden'); drawer.setAttribute('aria-expanded', 'false'); bell?.setAttribute('aria-expanded', 'false'); } });
  window.limparNotificacoes = async () => { try { await fetch(`${API}/notificacoes`, {method:'DELETE',credentials:'include'}); } finally { carregarNotificacoes(); } };
  window.abrirConversa = id => {
    const u = user();
    const familiar = String(u.userType || u.perfil || '').toLowerCase() === 'familiar';
    if (familiar) { conversaIdoso = String(id); conversaFamiliar = String(u.id); }
    else { conversaIdoso = String(u.id); conversaFamiliar = String(id); }
    conversaInicializada = false; ultimaMensagem = 0; carregarMensagens();
    if (el('chat-contact-select')) el('chat-contact-select').value = String(id);
    el('chat-panel')?.scrollIntoView({behavior:'smooth'});
  };
  document.addEventListener('DOMContentLoaded', () => {
    const form = el('chat-form'); form?.addEventListener('submit', enviar);
    el('chat-contact-select')?.addEventListener('change', e => {
      const u=user(); const familiar=String(u.userType||u.perfil).toLowerCase()==='familiar';
      if (familiar) { conversaIdoso=String(e.target.value); conversaFamiliar=String(u.id); }
      else { conversaIdoso=String(u.id); conversaFamiliar=String(e.target.value); }
      ultimaMensagem=0; conversaInicializada=false; carregamentoMensagens++; carregarMensagens();
    });
    el('chat-mic')?.addEventListener('click', iniciarDitado);
    const auto = el('chat-auto-audio'); if (auto) { auto.checked = localStorage.getItem('zelo-audio-auto') === 'true'; auto.addEventListener('change', () => localStorage.setItem('zelo-audio-auto', String(auto.checked))); }
    el('chat-read-last')?.addEventListener('click', () => { const messages = el('chat-messages')?.querySelectorAll('.chat-message span'); if (messages?.length) window.lerMensagemChat(messages[messages.length - 1].textContent); });
    const drawer = el('notif-drawer'); const bell = el('bell-btn'); if (drawer) { drawer.classList.add('hidden'); drawer.setAttribute('aria-expanded', 'false'); } bell?.setAttribute('aria-expanded', 'false');
    carregarContatos(); carregarNotificacoes();
    timer=setInterval(() => { carregarContatos(); carregarMensagens(); window.dispatchEvent(new Event('zelo-dados-atualizados')); }, 2000);
    timerNotificacoes=setInterval(() => { if (document.visibilityState === 'visible') carregarNotificacoes(); }, 15000);
  });
  window.addEventListener('zelo-vinculo-atualizado', () => { carregarContatos(); carregarNotificacoes(); });
  window.addEventListener('beforeunload', () => { clearInterval(timer); clearInterval(timerNotificacoes); });
})();
