(() => {
    'use strict';

    const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';
    // O worker fica sempre na raiz do frontend; usar caminho absoluto evita
    // que páginas em /compromissofamilia/ ou /remediofamiliar/ procurem
    // acidentalmente por /compromissofamilia/sw.js (404).
    const SW_URL = new URL('/sw.js', window.location.origin).toString();
    const SW_SCOPE = new URL('/', window.location.origin).pathname;
    let preparacaoPush = null;

    function usuarioLogado() {
        try { return JSON.parse(localStorage.getItem('currentUser') || 'null'); } catch (_) { return null; }
    }
    function base64ParaBytes(valor) {
        const preenchido = String(valor).replace(/-/g, '+').replace(/_/g, '/');
        const padding = '='.repeat((4 - (preenchido.length % 4)) % 4);
        const binario = atob(preenchido + padding);
        return Uint8Array.from(binario, (caractere) => caractere.charCodeAt(0));
    }
    function mostrarAviso(mensagem, tipo = 'info') {
        let aviso = document.getElementById('zelo-push-aviso');
        if (!aviso) {
            aviso = document.createElement('div');
            aviso.id = 'zelo-push-aviso';
            aviso.setAttribute('role', 'alert');
            aviso.style.cssText = 'position:fixed;z-index:10000;left:20px;right:20px;bottom:20px;padding:18px 20px;border-radius:14px;background:#fff;box-shadow:0 6px 24px rgba(0,0,0,.2);font:600 16px/1.4 Arial,sans-serif;color:#17324d;display:flex;gap:14px;align-items:center;justify-content:space-between;';
            document.body.appendChild(aviso);
        }
        aviso.style.borderLeft = `7px solid ${tipo === 'erro' ? '#c0392b' : '#2676d9'}`;
        aviso.innerHTML = `<span>${String(mensagem).replace(/[<>]/g, '')}</span><button type="button" aria-label="Fechar aviso" style="border:0;background:transparent;font-size:26px;cursor:pointer;padding:8px 12px">×</button>`;
        aviso.querySelector('button').onclick = () => aviso.remove();
        if (aviso._zeloTimeout) clearTimeout(aviso._zeloTimeout);
        aviso._zeloTimeout = window.setTimeout(() => { if (aviso.isConnected) aviso.remove(); }, 6000);
    }
    function verificarSuporte() {
        if (!window.isSecureContext) throw new Error('Notificações exigem uma conexão HTTPS. Abra o endereço oficial do Zelo.');
        if (!('serviceWorker' in navigator)) throw new Error('Este navegador não oferece Service Worker.');
        if (!('PushManager' in window)) throw new Error('Este navegador não oferece notificações push. No iPhone, adicione o Zelo à Tela de Início e abra pelo ícone do aplicativo.');
        if (!('Notification' in window)) throw new Error('Este navegador não oferece notificações do sistema.');
        const ios = /iPhone|iPad|iPod/i.test(navigator.userAgent) || (/Macintosh/i.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
        const instalado = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
        if (ios && !instalado) throw new Error('No iPhone ou iPad, adicione o Zelo à Tela de Início e abra pelo ícone. Web Push exige iOS/iPadOS 16.4 ou posterior.');
    }
    function prepararPush() {
        if (!preparacaoPush) {
            preparacaoPush = Promise.all([
                (async () => {
                    const controller = new AbortController();
                    const timeout = window.setTimeout(() => controller.abort(), 15000);
                    try {
                        const response = await fetch(`${API_BASE_URL}/notificacoes/push/configuracao`, {
                            credentials: 'include', cache: 'no-store', signal: controller.signal
                        });
                        const texto = await response.text();
                        let config = {};
                        try { config = texto ? JSON.parse(texto) : {}; } catch (_) {}
                        if (!response.ok) throw new Error(config.message || `Não foi possível consultar as notificações (${response.status}). Entre novamente no Zelo e tente outra vez.`);
                        if (!config.enabled || !config.publicKey) throw new Error('As notificações push ainda não estão configuradas no servidor.');
                        return config;
                    } finally { window.clearTimeout(timeout); }
                })(),
                (async () => {
                    const registro = await navigator.serviceWorker.register(SW_URL, { scope: SW_SCOPE, updateViaCache: 'none' });
                    await registro.update().catch(() => {});
                    return navigator.serviceWorker.ready;
                })()
            ]).then(async ([config, registro]) => ({
                config,
                registro,
                inscricao: await registro.pushManager.getSubscription()
            })).catch(erro => {
                preparacaoPush = null;
                throw erro;
            });
        }
        return preparacaoPush;
    }
    async function registrarInscricao() {
        verificarSuporte();
        if (!usuarioLogado()) throw new Error('Sua sessão terminou. Entre novamente no Zelo para ativar as notificações.');

        // Solicitar permissão antes de qualquer espera de rede preserva o toque do usuário,
        // exigido por navegadores móveis para exibir o prompt do sistema.
        let permissao = Notification.permission;
        if (permissao === 'denied') throw new Error('As notificações estão bloqueadas. Libere a permissão do site nas configurações do navegador e tente novamente.');
        if (permissao !== 'granted') permissao = await Notification.requestPermission();
        if (permissao !== 'granted') throw new Error('Permissão para notificações não concedida. Escolha “Permitir” quando o navegador perguntar.');

        const preparada = await prepararPush();
        let inscricao = preparada.inscricao;
        if (!inscricao) {
            inscricao = await preparada.registro.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: base64ParaBytes(preparada.config.publicKey)
            });
            preparada.inscricao = inscricao;
        }

        const resposta = await fetch(`${API_BASE_URL}/notificacoes/push/inscricoes`, {
            method: 'POST', credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(inscricao.toJSON())
        });
        const respostaTexto = await resposta.text();
        if (!resposta.ok) {
            let detalhe = '';
            try { detalhe = JSON.parse(respostaTexto).message || ''; } catch (_) {}
            throw new Error(detalhe || `Não foi possível salvar a inscrição (${resposta.status}).`);
        }
        preparacaoPush = Promise.resolve(preparada);
        localStorage.setItem('zeloPushAtivo', 'true');
        return true;
    }
    function adicionarBotaoAtivacao() {
        if (document.getElementById('zelo-ativar-push')) return;
        const botao = document.createElement('button');
        botao.id = 'zelo-ativar-push'; botao.type = 'button';
        botao.textContent = 'Preparando notificações neste aparelho…';
        botao.disabled = true;
        botao.setAttribute('aria-label', 'Ativar notificações neste aparelho');
        botao.style.cssText = 'position:fixed;z-index:9999;right:20px;bottom:20px;padding:16px 22px;border:0;border-radius:14px;background:#1d70d6;color:white;font:700 16px Arial,sans-serif;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.25);min-height:52px;';
        botao.onclick = async () => {
            botao.disabled = true; botao.textContent = 'Ativando...';
            try { await registrarInscricao(); botao.remove(); mostrarAviso('Notificações ativadas neste aparelho.', 'info'); window.dispatchEvent(new Event('zelo-push-estado-alterado')); }
            catch (erro) { botao.disabled = false; botao.textContent = 'Tentar ativar notificações novamente'; mostrarAviso(erro.message || 'Não foi possível ativar as notificações.', 'erro'); }
        };
        document.body.appendChild(botao);
        prepararPush().then(() => {
            if (!botao.isConnected) return;
            botao.disabled = false;
            botao.textContent = 'Ativar notificações neste aparelho';
        }).catch(() => {
            if (!botao.isConnected) return;
            botao.disabled = false;
            botao.textContent = 'Tentar ativar notificações neste aparelho';
        });
    }
    async function iniciar() {
        if (!usuarioLogado()) return;
        try {
            verificarSuporte();
            prepararPush().catch(erro => console.warn('[Zelo Web Push] Preparação do serviço:', erro));
            if (Notification.permission === 'granted') await registrarInscricao();
            else adicionarBotaoAtivacao();
        } catch (erro) { console.warn('[Zelo Web Push]', erro); adicionarBotaoAtivacao(); }
    }
    window.zeloAtivarNotificacoes = registrarInscricao;
    if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', (evento) => {
        if (evento.data?.tipo === 'WEB_PUSH_RECEBIDO') window.dispatchEvent(new CustomEvent('zelo-web-push', { detail: evento.data }));
    });
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar, { once: true }); else iniciar();
})();
