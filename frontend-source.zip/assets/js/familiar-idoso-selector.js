(() => {
    'use strict';

    const API_BASE_URL = window.ZELO_API_BASE_URL || 'http://localhost:8080';
    const STORAGE_KEY = 'selectedIdoso';

    function lerJSON(chave, fallback = {}) {
        try { return JSON.parse(localStorage.getItem(chave) || 'null') || fallback; } catch (_) { return fallback; }
    }

    function idNumerico(valor) {
        const numero = Number(valor);
        return Number.isFinite(numero) && numero > 0 ? numero : null;
    }

    function obterSelecionado() {
        const salvo = lerJSON(STORAGE_KEY, null);
        if (salvo && idNumerico(salvo.id)) return { id: idNumerico(salvo.id), nome: salvo.nome || '' };
        const usuario = lerJSON('currentUser');
        if (usuario && idNumerico(usuario.idIdoso)) return { id: idNumerico(usuario.idIdoso), nome: usuario.nomeIdoso || '' };
        return null;
    }

    function salvarSelecionado(idoso) {
        const valor = { id: idNumerico(idoso.id), nome: String(idoso.nome || 'Idoso vinculado').trim() || 'Idoso vinculado' };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(valor));
        window.dispatchEvent(new CustomEvent('zelo-idoso-selecionado', { detail: valor }));
        return valor;
    }

    function criarComponente() {
        if (document.getElementById('familiar-idoso-switcher')) return null;
        const ancora = document.querySelector('.user-pill, .user-profile-badge, .top-bar, .top-header');
        if (!ancora || !ancora.parentNode) return null;

        const wrapper = document.createElement('div');
        wrapper.id = 'familiar-idoso-switcher';
        wrapper.className = 'familiar-idoso-switcher';
        wrapper.innerHTML = '<label for="familiar-idoso-select">Gerenciando</label><select id="familiar-idoso-select" aria-label="Escolha o idoso que deseja gerenciar"><option value="">Carregando idosos...</option></select><span class="familiar-idoso-switcher-status" aria-live="polite"></span>';

        if (ancora.classList.contains('user-pill') || ancora.classList.contains('user-profile-badge')) {
            ancora.parentNode.insertBefore(wrapper, ancora);
        } else {
            ancora.appendChild(wrapper);
        }
        return wrapper;
    }

    function atualizarTextos(idoso) {
        if (!idoso) return;
        const nome = idoso.nome || 'Idoso vinculado';
        document.querySelectorAll('#current-idoso-label, #idoso-label, #nome-idoso-label, #nome-idoso, #header-nome-idoso').forEach(elemento => {
            if (elemento.id === 'current-idoso-label' || elemento.id === 'idoso-label') {
                elemento.textContent = `Idoso: ${nome}`;
            } else {
                elemento.textContent = nome;
            }
        });
        document.querySelectorAll('.idoso-info').forEach(elemento => {
            elemento.textContent = `Idoso: ${nome}`;
        });
    }

    async function carregarIdosos() {
        const componente = criarComponente();
        const usuario = lerJSON('currentUser');
        if (!componente || !usuario.id) return;
        const select = componente.querySelector('select');
        const status = componente.querySelector('.familiar-idoso-switcher-status');
        let idosos = [];

        try {
            const resposta = await fetch(`${API_BASE_URL}/api/vinculos/familiar/${encodeURIComponent(usuario.id)}/idosos`, { credentials: 'include', cache: 'no-store' });
            if (!resposta.ok) throw new Error('Não foi possível carregar os idosos vinculados.');
            const dados = await resposta.json();
            idosos = Array.isArray(dados) ? dados.map(item => ({ id: idNumerico(item.id), nome: String(item.nome || item.nomeCompleto || 'Idoso vinculado').trim() })).filter(item => item.id) : [];
        } catch (erro) {
            const atual = obterSelecionado();
            if (atual) idosos = [atual];
            if (status) status.textContent = 'Não foi possível atualizar os vínculos.';
        }

        if (!idosos.length) {
            select.replaceChildren(new Option('Nenhum idoso vinculado', ''));
            select.disabled = true;
            atualizarTextos(null);
            return;
        }

        const atual = obterSelecionado();
        const escolhido = idosos.find(item => atual && item.id === atual.id) || idosos[0];
        select.replaceChildren(...idosos.map(item => new Option(`${item.nome} · ID ${item.id}`, String(item.id))));
        select.value = String(escolhido.id);
        salvarSelecionado(escolhido);
        atualizarTextos(escolhido);

        select.addEventListener('change', () => {
            const novo = idosos.find(item => String(item.id) === select.value);
            if (!novo) return;
            salvarSelecionado(novo);
            atualizarTextos(novo);
            window.location.reload();
        });
    }

    document.addEventListener('DOMContentLoaded', carregarIdosos);
})();
