(() => {
    'use strict';
    function iniciarMenu() {
        const wrapper = document.querySelector('.wrapper');
        const toggle = document.getElementById('sidebar-toggle');
        if (!wrapper || !toggle || toggle.dataset.menuInicializado === 'true') return;
        toggle.dataset.menuInicializado = 'true';
        const chave = 'zelo_familiar_sidebar_collapsed';
        if (localStorage.getItem(chave) === '1' || window.innerWidth <= 700) wrapper.classList.add('sidebar-collapsed');
        const atualizar = () => {
            const recolhido = wrapper.classList.toggle('sidebar-collapsed');
            toggle.setAttribute('aria-expanded', String(!recolhido));
            toggle.setAttribute('aria-label', recolhido ? 'Expandir menu' : 'Recolher menu');
            localStorage.setItem(chave, recolhido ? '1' : '0');
        };
        toggle.addEventListener('click', atualizar);
        toggle.setAttribute('aria-expanded', String(!wrapper.classList.contains('sidebar-collapsed')));
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciarMenu, { once: true });
    else iniciarMenu();
})();
