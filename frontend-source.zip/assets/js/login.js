document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("login-form");
  const status = document.getElementById("login-status");
  if (!form || !status) return;

  async function fetchComTimeout(url, options, timeoutMs = 60000) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      const text = await response.text();
      return { response, text };
    } catch (error) {
      if (error.name === "AbortError") {
        const timeoutError = new Error("O servidor do Zelo demorou para responder. Aguarde um pouco e tente entrar novamente.");
        timeoutError.code = "TIMEOUT";
        throw timeoutError;
      }
      if (error instanceof TypeError) throw new Error("Não foi possível conectar ao servidor. Confira sua conexão e tente novamente.");
      throw error;
    } finally {
      window.clearTimeout(timer);
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const button = form.querySelector("button[type=submit]");
    const textoOriginal = button.textContent;
    button.disabled = true;
    button.textContent = "Conectando…";
    status.textContent = "Verificando seus dados...";
    const avisoLento = window.setTimeout(() => {
      if (button.disabled) status.textContent = "O servidor pode estar iniciando. Aguarde a resposta; a tela continuará disponível para tentar novamente se falhar.";
    }, 8000);

    try {
      const { response, text } = await fetchComTimeout(`${window.ZELO_API_BASE_URL}/login`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.elements.email.value.trim().toLowerCase(),
          senha: form.elements.senha.value,
          lembrarMe: form.elements.lembrarMe.checked
        })
      });
      if (!response.ok) {
        let message = text;
        try { message = JSON.parse(text).message || text; } catch (_) {}
        throw new Error(message || "Não foi possível entrar. Confira seus dados.");
      }

      let usuario;
      try { usuario = text ? JSON.parse(text) : {}; }
      catch (_) { throw new Error("O servidor retornou uma resposta inválida. Tente novamente."); }
      const perfil = String(usuario.perfil || usuario.tipo || "").trim().toLowerCase();
      if (perfil !== "idoso" && perfil !== "familiar") {
        throw new Error("Não foi possível identificar o perfil desta conta. Entre em contato com o suporte.");
      }
      usuario.userType = perfil;
      localStorage.setItem("currentUser", JSON.stringify(usuario));

      if (perfil === "idoso") {
        localStorage.setItem("selectedIdoso", JSON.stringify({ id: usuario.id, nome: usuario.nome }));
        window.location.replace("inicioidoso/inicioidoso.html");
      } else {
        localStorage.removeItem("selectedIdoso");
        window.location.replace("iniciofamiliar/iniciofamiliar.html");
      }
    } catch (error) {
      status.textContent = error.message || "Não foi possível conectar ao servidor. Tente novamente.";
    } finally {
      window.clearTimeout(avisoLento);
      button.disabled = false;
      button.textContent = textoOriginal;
    }
  });
});
