// Endereço da API. Em localhost/127.0.0.1 mantemos o mesmo host do frontend
// para que o cookie SameSite=Lax de desenvolvimento acompanhe as requisições.
(() => {
    const hostname = window.location.hostname;
    const local = hostname === '127.0.0.1' || hostname === 'localhost';
    const localBase = `http://${hostname}:8080`;
    const productionBase = 'https://zelo-backend-a84a.onrender.com';
    window.ZELO_API_BASE_URL = window.ZELO_API_BASE_URL || (local ? localBase : productionBase);
})();
